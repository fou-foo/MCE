#include <stdio.h>

void primero( )
{
    int a1, a2, swap;
    scanf("Ingrese el primer número entero:\n", &a1);
    scanf("Ingrese el segundo número entero:\n", &a2);
    printf("El primer número es :", &a1);
    printf("El segundo número es :", &aa);





}


void main()
{
    int opcion;
                                                            # Se construye el menu
    printf("Tarea 3: Tester\n Elija un número para ver la opción correpondiente al inciso de la tarea: \n");
    printf("1 ) Programa que ingrese dos enteros y cambiar sus valores. Imprima valores originales y los  modificados.\n");
    fflush(stdin);
    scanf("Digite su eleccion:\n", &opcion);

}


