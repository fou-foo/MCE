gc()
setwd("/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio4/")
path.imagenes <- 'img_expression/'
etiquetas <- read.csv("/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio4/class_img_exp.dat", sep="")
etiquetas$file <- as.character(etiquetas$file)
mujeres <-  unlist(lapply(etiquetas$file, function(x) unlist(strsplit(x, split ='\\.'))[1]))
table(mujeres) #distribucion del numero de fotos por mujer, no es una muestra equilibrada
image(table(mujeres, etiquetas$semantic.expression))
image(table(mujeres, etiquetas$file.expression))
library(tiff)
library(imager)
imagenes <- list.files(path.imagenes)
#########################
img.to.array <- function(i)
{
    #funcion para ler tiff a jpg y luego pasarla a escala de grises
    name <- paste0(path.imagenes, imagenes[i])
    #img <- readTIFF(name)
    img <- load.image(name)
    img <- as.cimg(img)
    plot(img)
    img.gray <- grayscale(img)
    plot(img.gray)
    vec <- unlist(img.gray)
    return(vec)
}
########################## mi adaboost ############
##############################################################
library(rpart)
mypred <- function(r1,...)
{
    #funcion para predecir recibe un objeto de la clase 'rpart' 
    #regresa la prediction maximo verosimil 
    y_hat <- predict(r1, ...)
    y_hat <- apply(y_hat, 1, which.max)
    y_hat
}
boost <- function(x, y, M, maxdepth=2, normalpha=F, cp = 0.01, minsplit = 50)
{
    #funcion de boost para arboles
    #x (dataframe)
    #y (vector) : corresponde a las etiquetas de las observaciones de 'x'
    N <- length(y)
    w <- rep(1/N, N) # apriori uniforme
    yhat <- matrix(0, ncol = M, nrow = N)
    err <-  rep(1, M)
    alpha <- rep(1/M, M) #pesos identicos al inicio
    treelist <- vector('list', M) #lista para cuardar los clasificadores debiles
    data.train <- data.frame(x=x,y=y)
    k <- length(unique(data.train$y)) #numero de categorias
    for(m in 1:M)
    {
        if(m%%50==0)
            print(m) #para darnos una idea de en que iteracion va 
        treelist[[m]] <- rpart(y~., data=data.train, method='class', 
                               control = rpart.control(cp = cp, minsplit=minsplit, maxdepth=maxdepth), 
                               weights=w) #entremos las funciones base
        yhat[,m] <- mypred(treelist[[m]]) #recalibramos
        diferentes <- yhat[,m]!= as.numeric(y)
        if(sum(diferentes) == 0) #por si en un conjunto facíl se logra el cero (como en el conjunto de datos 'iris')
        {
            indices <- lapply(treelist, FUN = function(x) {return(!is.null(x))})
            indices <- unlist(indices)
            cat('Error cero alcanzado en iteracion: ', m)
            return(list(treelist=treelist[indices], 
                        alpha=alpha[indices], 
                        weights=w[indices], error=err[indices]))
        }
        err[m] <- sum(w*( diferentes )) /sum(w) #numero de errores en este clasificador debil 'm'
        alpha[m] <- log((1-err[m])/err[m]) + log( k -1 )  #la GRAN diferencia entre arboles y adaboost
        w <- w*exp(alpha[m]* ( diferentes )) #actualizacion de pesos
        w <- w/sum(w**2)**.5
    }
    #if(normalpha)
    #   alpha <- alpha/sum(alpha)
    result <- list(treelist=treelist,alpha=alpha,weights=w,error=err)
    class(result) <- 'boost'
    return(invisible(result))
}
predict.boost <- function(bo, x, y, M=length(bo$treelist), verbose=F)
{
    newdata <- data.frame(x=x,y=y)
    yhat <- rep(-1,nrow(newdata))
    k <- length(unique(y))
    eval <- rep(-1, k)
    #names(eval) <- as.character(unique(etiquetas$semantic.expression))
    cuenta <- 0
    votos <- rep(-1,M)
    for(j in 1:nrow(newdata)) #para cada observacion estimamos su prediccion 
    {
        if(j%%100==0)
            print(j) #para darnos una idea de en que iteracion va 
        eval <- rep(-1, k)
        for(m in 1:M)#evaluamos la observacion en cada arbol
        {
            votos[m] <- mypred( bo$treelist[[m]], newdata=newdata[j,], weights=bo$weights ) 
        }
        for (l in 1:k) #guardamos los resultados de cada clase
        {
            eval[l] <- sum(bo$alpha*(votos == l))
        }
        yhat[j] <- as.character(unique(etiquetas$semantic.expression))[which.max(eval)] #regresamos la maximo verosimil
    }
    return(list( class=yhat))
}
################## componentes con toda la muestra
X <- mapply(img.to.array, 1:length(imagenes))
#str(X)
X <- t(X)
#media <- apply(X, 2, mean)
#plot(as.cimg(media))#veamos la imagen media
#X.centrada <- X- media  #centramos las imagenes
#str(X.centrada)
#S <- cov(X.centrada) es impractico
#all <-prcomp(X.centrada, center=FALSE) #usando svd
#summary(all)
#valores <- all$sdev**2
#plot(cumsum(valores )/sum(valores))
#prod(all$sdev)
#abline(h = .90)
#which(cumsum(valores)/sum(valores) <=.9) #23 luce bien para el 95% y 10 para el 90, 56 para 98
#plot(as.cimg(all$rotation[,3]))
#todas <- data.frame(x = 1:180, y= cumsum(valores )/sum(valores)  )
#todas$muestra <- 'Todas las componentes'
################ dividamos la muestra en dos para ver la estabilidad de 'p'
#set.seed(1000)
#dim(X.centrada)
#indice.1 <- sample(1:dim(X)[1], round(dim(X)/2) )
#sub.muestra1 <- X[indice.1, ]
#str(sub.muestra1)
#sub.muestra1 <- t(sub.muestra1)
#media <- apply(sub.muestra1, 1, mean)
# plot(as.cimg(media))#veamos la imagen media de la submuestra
# X.centrada <- sub.muestra1- media  #centramos las imagenes
# X.centrada <- t(X.centrada)
# all.1 <- prcomp(X.centrada)
# valores <- all.1$sdev**2
# plot(cumsum(valores)/sum(valores))
# abline(h = .98)
# which(cumsum(valores)/sum(valores) <=.90) #46 luce bien para el 95% y 27 para el 90, 65 para el 98
# muestra1 <- data.frame(x=1:90, y =cumsum(valores )/sum(valores)  )
# muestra1$muestra <- 'Muestra1'
# ###################### segunda submuestra
# sub.muestra2 <- X[-indice.1, ]
# sub.muestra2 <- t(sub.muestra2)
# media <- apply(sub.muestra2, 1, mean)
# plot(as.cimg(media))#veamos la imagen media de la submuestra
# X.centrada <- sub.muestra2- media  #centramos las imagenes
# X.centrada <- t(X.centrada)
# all <-prcomp(X.centrada)
# valores <- all$sdev**2
# plot(cumsum(valores)/sum(valores))
# abline(h = .98)
# which(cumsum(valores)/sum(valores) <=.9) #45 luce bien para el 95% y 28 para el 90, 64 para el 98
# muestra2 <- data.frame(x = 1:90, y=cumsum(valores )/sum(valores)  )
# muestra2$muestra <- 'Muestra2'
################grafica 
# data <- rbind(todas, muestra1, muestra2)
# library(ggplot2)
# ggplot(data, aes(x=x, y =y , color = muestra)) +geom_line() +ylim(c(0.5,1)) +xlab('No. componentes')+
#     ylab('% var. explicada') +theme_minimal() + ggtitle('Estabilidad en la elección de parámetro p')+
#     geom_hline(yintercept = .95, color = 'red') + geom_vline(xintercept = 45, color = 'red')
# ################### p = 45
p <- 45
################### adaboost
set.seed(0)
indices <- sample(1:dim(X)[1], round(dim(X)[1]*.8))
train <- X[indices, ]
test <- X[-indices,]
y.train <- etiquetas$semantic.expression[indices]
y.test <- etiquetas$semantic.expression[-indices]
media <- apply(train, 2, mean)
plot(as.cimg(media))#veamos la imagen media del train
train.centrada <- train- media  #centramos las imagenes
all <-prcomp(train.centrada, center=FALSE) #usando svd
valores <- all$sdev**2
vec.pro <- all$rotation[,1:p]   #Se usaron 45 componentes principales porque explican cerca de 75% de la varianza
train <- train %*% vec.pro
test <- test %*% vec.pro
adaboost <- boost(x = train, y = y.train , M = 100, maxdepth = 10, cp = .0001, minsplit = 3)
plot(adaboost$error, type='l', xlab = 'No. iteraciones', ylab='Porcentaje de error en entrenamiento', col ='navy', main='Variable semantic.expression')
gc()
(y_hat <- predict.boost(adaboost, x = test, y = y.test)) #
accuracy <- caret::confusionMatrix(y.test, factor(y_hat$class))
(accuracy <- accuracy$overall[['Accuracy']])
gc()
############################################################## Prueba con mis fotos
setwd("/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio4/foo")
class(dir())
foos <- dir()
foos <- data.frame(file = dir())
foos$file <- as.character(foos$file)
etiquetas.foo <-  unlist(lapply(foos$file, function(x) unlist(strsplit(x, split ='\\.'))[2]))
path.imagenes <- '/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio4/foo/'
imagenes <- dir()
X <- mapply(img.to.array, 1:length(imagenes))
validacion <- t(X)
validacion <- validacion %*% vec.pro
y_hat <- predict.boost(adaboost, x = validacion , y = etiquetas.foo)
accuracy <- caret::confusionMatrix(y.test, factor(y_hat$class)) #todas DIS
(accuracy <- accuracy$overall[['Accuracy']])

##############################3 ahora para la variable semantic.expression
set.seed(0)
indices <- sample(1:dim(X)[1], round(dim(X)[1]*.8))
train <- X[indices, ]
test <- X[-indices,]
y.train <- etiquetas$file.expression[indices]
y.test <- etiquetas$file.expression[-indices]
media <- apply(train, 2, mean)
plot(as.cimg(media))#veamos la imagen media del train
train.centrada <- train- media  #centramos las imagenes
all <-prcomp(train.centrada, center=FALSE) #usando svd
valores <- all$sdev**2
vec.pro <- all$rotation[,1:p]   #Se usaron 45 componentes principales porque explican cerca de 75% de la varianza
train <- train %*% vec.pro
test <- test %*% vec.pro
adaboost <- boost(x = train, y = y.train , M = 50, maxdepth = 10, cp = .0001, minsplit = 3)
plot(adaboost$error, type='l', xlab = 'No. iteraciones', ylab='Porcentaje de error en entrenamiento', col ='purple', main='Variable file.expression')#acc .6944
gc()
y_hat <- predict.boost(adaboost, x = test, y = y.test)
accuracy <- caret::confusionMatrix(y.test, factor(y_hat$class))
(accuracy <- accuracy$overall[['Accuracy']])
gc()
