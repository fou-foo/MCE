setwd('/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio5')
pelis <- read.csv('movie_metadata.csv', stringsAsFactors = FALSE, na.strings = '')
#############imputamos datos con la mode:maximoverosimil
library(imputeMissings)
data <- impute(pelis, method='median/mode')
able(tipos) #12 variable ordinales y 16 continuas
names(data)
y <- data$gross
saveRDS(y,'y.rds')
data$gross <-NULL
tipos <- unlist(lapply(data, class))
ordinales <- names(data)[tipos == 'character']
col <- match(ordinales, names(data))
tipos[col]
data.ordinal <- data[,col]
data.continua <- data[, -col]
summary(data.ordinal)
summary(data.continua)
#indices <- is.na(data.ordinal)
#sum(indices)
#indices <- is.na(data.continua)
#sum(indices)
library(ggcorrplot)
library(GGally)
r <- cor(data.continua)
ggcorrplot(r, title = "Correlations between 11 initial variables",
           colors = c("deeppink", "white", "deepskyblue"),  type = "lower",
           outline.col = "white")

#for(i in ordinales)
#{
#   plot(table(data.ordinal[,i] ), main=i)
#  scan()
#}
library(smacof)
library(cluster)
data.factor <- as.data.frame(apply(data.ordinal, 2, factor))
distancias <- daisy(data.factor, metric='gower', type =list(ordratio=names(data.ordinal)))
(salida1 <- smacofSym(distancias, ndim = 7 )) #stress 0.0663-11 # 0.077 con 8, .09 con 7.15 para 5
salida <- salida1
salida$stress
salida <- salida$conf
r <- cor(as.data.frame(salida))
ggcorrplot(r, title = "Correlations between 11 initial variables",
           colors = c("deeppink", "white", "deepskyblue"),  type = "lower",
           outline.col = "white")
det(r)
plot(salida)
data.continua <- scale(data.continua)
salida <- scale(salida)
pca.continuo <- prcomp(data.continua)
pca.continuo
plot(pca.continuo)
summary(pca.continuo)
plot(cumsum(pca.continuo$sdev**2)/sum(pca.continuo$sdev**2), type='l')
data.continua <- pca.continuo$x[,1:11]
data.continua <- as.data.frame(data.continua)
mix.pca <- cbind(data.continua, salida)
#saveRDS(mix, file='mix.rds')
saveRDS(mix.pca, file='mixpca.rds')
################ vamor por el favorito de todos SVM###########################
train.SVM.init <- function(cv = 10, data, x)
{
    library(e1071)
    set.seed(0)
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    function(x){
        for (i in 1:(length(breaks)-1))
        {
            indices <- breaks[i]:breaks[i+1]
            test <- as.data.frame(data[ indices,   ])
            train <- as.data.frame(data[ -indices,   ])
            y_hat <- svm(y ~ ., data = train, kernel='linear', cost = x ) #siguiendo la recomendación de hestie
            y.hat.train <-  predict(y_hat, train )
            acc.train[i] <- (sum((y.hat.train-train$y)**2)**.5)/length(y.hat.train)
            y.hat.test <- predict(y_hat, test)
            acc.test[i] <- (sum((y.hat.test-test$y)**2)**.5)/length(y.hat.test)
        }
        gc()
        return( list(train=acc.train, test =acc.test) )
    }
}
t1 <- Sys.time()
train.SVM <- train.SVM.init(cv = 5, data = cbind(mix,y), x)
error.SVM <- train.SVM(1)#determinado por busqueda exaustiva en [.1, 20]
t1 <- t1 -Sys.time()
t1
error.SVM <- as.data.frame(error.SVM)
error.SVM$modelo <- 'SVM'
error.SVM
p1 <-ggplot(error.SVM, aes(x = modelo, y = train, color = I('purple'))) + geom_boxplot() +geom_jitter(width = 0.2, alpha = 0.4, color ='navy')+
    theme_minimal() +xlab('') + ylab('MSE en conjunto de entrenamiento')+
    ggtitle('MSE entre modelos en 5-Folds (conjunto de peliculas)')+ylim(c(80000,3500000))
p2 <-ggplot(error.SVM, aes(x = modelo, y = test, color = I('orange'))) + geom_boxplot() +geom_jitter(width = 0.2, alpha = 0.4, color ='navy')+
    theme_minimal() +xlab('') + ylab('MSE en conjunto de prueba')+
    ggtitle('MSE entre modelos en 5-Folds (conjunto de peliculas)')+ylim(c(80000,3500000))
library(ggpubr)
ggarrange(p1,p2)
############################################  busqueda en grid del parametro C de SVM el mejor es .1
setwd('/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio5')
#mix <- readRDS(file='mix.rds')
mix <- readRDS(file='mixpca.rds')
y <- readRDS(file='y.rds')
class(mix)
train.SVM <- train.SVM.init(cv = 5, data = cbind(mix,y), x)
c.tuning <- seq(.1, 10, length=10)
library(parallel)
t1 <- Sys.time()
searh.grid.SVM <- mclapply(FUN = train.SVM,  X= c.tuning, mc.cores = (detectCores())-1)
searh.grid.SVM
t1 <- t1 -Sys.time()
t1
z <- as.data.frame(searh.grid.SVM)
z2 <- as.data.frame(apply(z, 2, mean))
z.vis <- matrix(0, ncol = 2, nrow = 10)
impares <-  seq(1,dim(z2)[1], by = 2)
z.vis[,1 ] <- z2$`apply(z, 2, mean)`[impares]
z.vis[,2 ] <- z2$`apply(z, 2, mean)`[impares+1]
library(ggplot2)
z.vis <- as.data.frame(z.vis)
colnames(z.vis) <- c('Acc.Train', 'Acc.Test')
z.vis$Indice.Grid <- 1:length(c.tuning)
saveRDS(z.vis, file ='tuning_SVM.rds')
z.vis <-readRDS(file='tuning_SVM.rds')
p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
    geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
    ggtitle('Precisión promedio por valor del grid (10-fold): SVM')
library(plotly)
p2 <- ggplotly(p2) #distro en bayes
p2
