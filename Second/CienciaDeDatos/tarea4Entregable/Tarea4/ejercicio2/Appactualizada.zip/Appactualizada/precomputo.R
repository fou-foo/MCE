###Lectura de datos y formación d eun solo dataset para hacer cv: DATOS de DIGITOS 
setwd('/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/ejercicio2/')
train <- read.table( 'oef.train')
#train$V1 <- factor(train$V1)
#saveRDS(train, 'train.rds')
#test <- read.table( 'oef.test')
#test$V1 <- factor(test$V1)
#saveRDS(rbind(train,test), 'datos.rds')

train <- readRDS( 'train.rds')
data <- readRDS('datos.rds')
##############################################################33
###################33 eigenfaces ########################################
# de la tarea 1 dije que usar 50 componentes era suficiente
set.seed(0)
p <- 50 #fijado con anterioridad
y <- train[,1]
y <- factor(y)
Y <- model.matrix(~y-1)
pca <- princomp(train[,-1]) #como los datos ya estan escalados en [-1, 1] uso la matriz de varianzas y covarianzas
z <- pca$loadings[,1:p]
saveRDS(z, 'componentes_pca.rds')
Z <- as.matrix(train[,-1]) %*%z
y_hat <- lm(Y  ~ . -1 , data = as.data.frame(Z))
b <- y_hat$coefficients
saveRDS(b, 'coeficientes_lm.rds')
##############vamos por el lda#############################################
set.seed(0)
library(MASS)
y_hat <- lda( V1~ ., data = train) 
saveRDS(y_hat, file='lda.rds')
set.seed(0)
p <- 50
Z <-  as.data.frame(Z)
Z$V1 <- train$V1
y_hat <- qda(V1 ~ .  , data = as.data.frame(Z))
saveRDS(y_hat, 'qda.rds')
################ vamos por la red ###############################3
library(nnet)
set.seed(0)
y_hat <- nnet(V1 ~ ., data = train, size = 3) #siguiendo la recomendación de hestie
saveRDS(y_hat, 'nn.rds')
################ vamor por el favorito de todos SVM###########################
library(e1071)
set.seed(0)
c.tuning <- seq(0.1, 20, length=15)
saveRDS(c.tuning, 'grid.svm.rds')
y_hat <- svm(y =train[,1] , x = train[,-1], kernel='linear', cost = .1 ) #sigueindo lo que se encontro en el grid
class(y_hat)
saveRDS(y_hat, 'svm2.rds')
############################################  busqueda en grid del parametro C de SVM el mejor es .1
z.vis <-readRDS(file='tuning_SVM.rds')
p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
    geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
    ggtitle('Precisión promedio por valor del grid (10-fold): SVM')
p2 <- ggplotly(p2) #distro en bayes
p2
############# vamos por el arbol################################
arbol <- rpart(V1  ~ ., data = train, method='class',
               control = rpart.control(cp = .01, minsplit= 20,
               maxdepth=15))
saveRDS(arbol, 'arbol.rds')
#tuning el arbol 
grid <- data.frame(maxdepth = rep(1:15, each= 4), minsplit = rep((1:4)*5, 15))
saveRDS(grid, file='grid_arbol.rds')
###################### NO  reutilizamos nuestra implementación de adaboost#################
set.seed(0)
library(adabag)
y_hat <- boosting( V1~ ., data= cbind(train), boos=FALSE, coeflearn = 'Zhu', mfinal = 50, 
                           control=rpart.control( maxdepth= 10 ,  minsplit = 9, cp =0.01 ) ) 
saveRDS(y_hat, file='ada.rds')
grid.ada <- data.frame(minsplit = rep(seq(5, 20, by=2),  each = 9 ),
                       maxdepth = rep(seq(5,  15, by =5 ), each =  3), 
                       mfinal = rep(c(50, 100, 500), 4) )
grid.ada <- unique(grid.ada)
saveRDS(grid.ada, 'grid_ada.rds')
#saveRDS(z.vis, file ='tuning_ada.rds')
readRDS(file='tuning_ada.rds')
p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
    geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
    ggtitle('Precisión promedio por valor del grid (10-fold): Arboles ')
p2 <- ggplotly(p2) #distro en bayes
p2
###########3grafico para comparar los desempellos en el dataset de numeros ##########
gc()
library(ggpubr)
errores <- rbind(error.lm, error.lda, error.qda, error.nn, error.SVM, error.arbol, error.ada)
p1 <-ggplot(errores, aes(x = modelo, y = train, color = modelo)) + geom_boxplot() +geom_jitter(width = 0.2, alpha = 0.4, color ='navy')+
    theme_minimal() +xlab('') + ylab('Presición en conjunto de entrenamiento')+ 
    ggtitle('Desempeño comparado entre modelos en 10-Folds (dataset números)')
p2 <- ggplot(errores, aes(x = modelo, y = test, color = modelo)) + geom_boxplot() +geom_jitter(width = 0.2, alpha = 0.5, color = 'navy')+
    theme_minimal() +xlab('') + ylab('Presición en conjunto de prueba')+ 
    ggtitle('Desempeño comparado entre modelos en 10-Folds (dataset números)')
ggarrange(p1,p2)
