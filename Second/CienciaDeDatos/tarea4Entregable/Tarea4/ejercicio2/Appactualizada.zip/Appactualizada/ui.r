###############################################################
## Ejemplo que captura un numero y lo proyecta en los primeros
## 50 componentes principales previamente calculados en un
## conjunto de datos de entrenamiento y guardados en pc.rds
## y los predice con diferentes metodos de claseificacion
## j. Antonio Garcia jose.ramirez@cimat.mx
###############################################################
library(shiny) 
library(shinythemes)
library(shinydashboard)
library(pixels)
library(plotly)
library(nnet)
shinyUI(fluidPage(
  theme = shinytheme("cerulean"),
  h1("Reconociendo números"),
  mainPanel(
    tabsetPanel( type="tabs", id = 'Clasificador',
      tabPanel('Introduce tu dígito',
               tabItem(tabName="main",hr(), 
                       fluidRow(column(3), column(5, h4("Dibuja el número"),  shiny_pixels_output( outputId = "pixels")),
                                        column(1,hr(),hr(),actionButton("captureDigit", "Capturar") ) , column(3)),
                       fluidRow(hr()),
                       fluidRow(column(4 , h3("Clasificación con Eigen faces"), verbatimTextOutput("lm") ),
                                column(4, h3("LDA dice que es: un "),  verbatimTextOutput("lda") ),
                                column(4, h3("QDA lo reconoce como  :"),  verbatimTextOutput("qda") ) ),
      fluidRow(column(4 , h3("Clasificación con arboles"), verbatimTextOutput("arbol") ),
               column(4, h3("SVM dice: un "),  verbatimTextOutput("svm") ),
               column(4, h3("NN atina a que es:"),  verbatimTextOutput("nn") ) )) ,
      fluidRow(column(4, h3("Adabbost veredicta :"),  verbatimTextOutput("ada") ) )) , 

       tabPanel( "Afinando parámetros ", 
                 tabItem(tabName = 'Afinando parámetros'), hr(),
                 column(12,  plotlyOutput("SVM"), 
                     h4('Con el grid:'),   verbatimTextOutput('svm.grid')),
                     
                     column(12, plotlyOutput("ARBOL"), 
                         h4('Con el grid:'),  verbatimTextOutput('arbol.grid')),
                     
                     column(12, plotlyOutput("ADA"), 
                            h4('Con el grid:'),  verbatimTextOutput('ada.grid')  ) )  
                       
)
      )
)
)    
  

