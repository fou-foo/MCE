###############################################################
## Ejemplo que captura un numero y lo proyecta en los primeros
## 50 componentes principales previamente calculados en un
## conjunto de datos de entrenamiento y guardados en pc.rds
## y los predice con diferentes metodos de claseificacion
## j. Antonio Garcia jose.ramirez@cimat.mx
#setwd('/srv/shiny-server/sample-apps/shiny-server/Appactualizada/')
###############################################################
library(shiny) 
library(pixels)
library(plotly)
library(MASS)
library(ggplot2)
library(rpart)
library(e1071)
library(nnet)
library(adabag)
## carga el objeto que contiene los PC calculados previamente
z <- readRDS("componentes_pca.rds")
## coeficientes
B <- readRDS('coeficientes_lm.rds')
train  <- readRDS( 'train.rds')
########modelos entranados
lda.model <- readRDS('lda.rds')
qda.model <- readRDS('qda.rds')
arbol.model <- readRDS('arbol.rds')
svm.model <- readRDS('svm2.rds')
nn.model <- readRDS('nn.rds')
ada.model <- readRDS('ada.rds')


shinyServer(function(input, output) 
{
  
  #####################3
  r.scale <- function(m)
  {
    #funcion para que la entrada de pixeles tenga la misma escala que los datos
    max <- max(m)
    min <- min(m)
    m <- ((m - min)/ (max - min)) # m \in [0,1]
    m*2-1     #asi m \in [-1, 1]
  }
  
  output$pixels <- shiny_render_pixels(
    show_pixels(grid=c(16,16), brush=matrix(c(1,1,1,1),2,2))) #obtencion de los pixeles
    output$prompt <- renderText("Dibuja un número de una cifra")
    observeEvent(input$captureDigit,
    {
        dig <<- (input$pixels)
        data.digit <- matrix(dig,nrow=16,ncol=16,byrow=T)        
        output$pixels <- shiny_render_pixels( show_pixels(grid=c(16,16), brush=matrix(c(.5,1,.5,1,1,1,.5,1,.5),3,3))   )
        ###########3 LDA
        output$lda <- renderPrint({
            #dig <- runif(256,-1,1)
            entrada <- r.scale(dig)
            entrada <- matrix(entrada, ncol = 256)
            entrada <- as.data.frame(entrada)
            names(entrada) <- paste0('V', 2:257)
            y <- predict( lda.model,   entrada)$class
            as.numeric(as.character(y))
        }) 
    ###########3 eigenfaces
        output$lm <- renderPrint({
            entrada <- r.scale(dig)
            proj <-entrada%*%z
            Y.hat.probs <- proj %*%B
            Y.hat <- which.max(Y.hat.probs)
            Y.hat <- Y.hat - 1 
            Y.hat
    })
    
    ###############3 QDA 
    output$qda <- renderPrint({
        entrada <- r.scale(dig)
        proj <-entrada%*%z
        entrada <- matrix(proj, byrow = TRUE, ncol = 50)
        entrada <- as.data.frame(entrada)
        names(entrada) <- paste0('Comp.', 1:50)
        y <- predict(qda.model, entrada)$class
        as.numeric(as.character(y))
    }) 
    #################arbol
     output$arbol <- renderPrint({
         entrada <- r.scale(dig)
         entrada <- matrix(entrada, ncol = 256)
         entrada <- as.data.frame(entrada)
         names(entrada) <- paste0('V', 2:257)
         foo1 <- predict(arbol.model, entrada, type = 'class')
         a <- as.numeric(as.character(foo1))
         a
     })
     
     ################# el consentido SVM
     output$svm <- renderPrint({
         entrada <- r.scale(dig)
         entrada <- matrix(entrada, ncol = 256)
         entrada <- as.data.frame(entrada)
         names(entrada) <- paste0('V', 2:257)
         foo1 <- predict(svm.model, entrada)
         a <- as.numeric(as.character(foo1))
         a
     })
    # ############# ada
     output$ada <- renderPrint({
         entrada <- r.scale(dig)
         entrada <- matrix(entrada, ncol = 256)
         entrada <- as.data.frame(entrada)
         names(entrada) <- paste0('V', 2:257)
         foo1 <- predict(ada.model, entrada)$class
         a <- as.numeric(as.character(foo1))
         a
     })
     # ############# nn
     output$nn <- renderPrint({
         entrada <- r.scale(dig)
         entrada <- matrix(entrada, ncol = 256)
         entrada <- as.data.frame(entrada)
         names(entrada) <- paste0('V', 2:257)
         foo1 <- predict(nn.model, entrada, type = 'class')
         a <- as.numeric(as.character(foo1))
         a
     })
    })
    
    output$SVM <- renderPlotly({
        z.vis <-readRDS(file='tuning_SVM.rds')
        p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
            geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
            ggtitle('Precisión promedio por valor del grid (10-fold): SVM')
        p2 <- ggplotly(p2) #distro en bayes
        p2
    })
    output$svm.grid <- renderPrint({
        z.vis <-readRDS(file='grid.svm.rds')
        t(z.vis)
    })
    output$ARBOL <- renderPlotly({
        z.vis <-readRDS(file='tuning_arbol.rds')
        p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
            geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
            ggtitle('Precisión promedio por valor del grid (10-fold): arbol')
        p2 <- ggplotly(p2) #distro en bayes
        p2
    })
    output$arbol.grid <- renderPrint({
        z.vis <-readRDS(file='grid_arbol.rds')
        t(z.vis)
    })
    output$ADA <- renderPlotly({
        z.vis <-readRDS(file='tuning_ada.rds')
        p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
            geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
            ggtitle('Precisión promedio por valor del grid (10-fold): Adaboost')
        p2 <- ggplotly(p2) #distro en bayes
        p2
    })
    output$ada.grid <- renderPrint({
        z.vis <-readRDS(file='grid_ada.rds')
        t(z.vis)
    })
})


    


