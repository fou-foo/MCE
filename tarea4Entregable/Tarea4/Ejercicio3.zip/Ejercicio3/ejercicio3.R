###Lectura de datos y formación d eun solo dataset para hacer cv: DATOS de frutas 
setwd('/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio3/data_fruits_tarea/')
imagenes <- dir()
library(imager)
index <- length(imagenes)
###################################### Representacion por cuantiles centrales en HSV
###### se termina preprocesamiento
#la siguinete funcion la utilice en su momento para extraer los
# cuartiles sin considerar el preprocesamiento dd quitar los pixeles cercanos al 
# pixel blanco, como se obtuvieron resultados pobres se abandono este esquema
reduce.a.medianas.HSV <- function(index)
{
    fruta <- load.image(file=imagenes[index])
    fruta <- RGBtoHSV(fruta)
    mediana <- apply(fruta[,,1,1:3], 3, function(x){
        quantile(x, probs = c(.25, .5, .75 ))
    })
    medianas <- matrix(mediana, byrow = TRUE, ncol = 9)
    colnames(medianas) <- c('H.25','H.5', 'H.75',
                            'S.25','S.5', 'S.75',
                            'V.25','V.5', 'V.75')
    row.names(medianas) <- index
    return(medianas)
}
medianas <- mapply(1:1300, FUN = reduce.a.medianas.HSV)
medianas <- as.data.frame(t(medianas))
colnames(medianas) <- c('H.25','H.5', 'H.75',
                        'S.25','S.5', 'S.75',
                        'V.25','V.5', 'V.75')
#se copian columnas  con el tipo de fruta sin importar su orientacion y consideracndo su orientacion
library(stringr)
imagenes.nombres <-str_split(imagenes,regex("[:digit:]"),simplify = T)[,1]# "Eliminar de un digito hacia adelante"
imagenes.nombres <- str_split(imagenes.nombres, regex("$"),simplify = T)[,1]  # Elimnar los "" finales
imagenes.nombres <-str_split(imagenes.nombres, regex("r$"),simplify = T)[,1]  # "Eliminar de un "_r" hacia adelante"
medianas$tipo <- imagenes.nombres #se agregan al conjunto de datos los nombres 'tipos' de frutas
medianas$tipo <- factor(medianas$tipo)
medianas$tipo2 <- medianas$tipo
################## se termina d epreparar el dataset 
#comienza tuning de parametros y seleccion del modelo
nombres <-     c("AppleBraeburn",       "AppleBraeburn" , "AppleGolden" ,        "AppleGrannySmith",  
                 "AppleGrannySmith", "Apricot" ,            "Apricot",            "Avocado" ,            
                 "Avocado" ,           "Carambula" ,        "Carambula",          "Cherry",              
                 "Cherry",             "Huckleberry",       "Huckleberry",        "Kiwi" ,               
                 "Kiwi" ,              "Orange",            "Orange",             "Peach",               
                 "Peach" ,             "Pineapple",         "Pineapple" ,         "Strawberry",          
                 "Strawberry" )  
levels(medianas$tipo2) <- nombres 
data <- medianas
data$tipo <- NULL
##############################################################33
library(caret)
library(plotly)
library(ggplot2)
library(ripa)
library(parallel)
set.seed(0)
###################33 eigenfaces ########################################
# # de la tarea 1 dije que usar 50 componentes era suficiente
# #primero cuantas componentes utilizar para lel metodo de regresión sobre pca
# Constructor.evaluar.p <- function(p,data)
# {
#     #construyo un 'closure' para no recalcular la matriz de componentes principales
#     #p  (int): numero de componentes a utilizar
#     # data (data-frame) con las observaciones
#     #ESTA FUNCION REGRESA UNA FUNCION, pero calcula la matriz de componentes principales
#     set.seed(0)
#     indices <- sample(1:dim(data)[1], round(dim(data)[1]*.8))
#     pca <- princomp(data[indices , -10]) #como los datos ya estan escalados en [-1, 1] uso la matriz de varianzas y covarianzas
#     y_train <- data[indices, 10 ]
#     Y_train <- model.matrix(~y_train-1)
#     function(p)
#     {
#         z <- pca$loadings[,1:p]
#         Z <- as.matrix(data[indices,-10]) %*%z
#         b <- lm(Y_train ~ . -1, data=as.data.frame(Z))
#         B <- b$coefficients
#         Y.train.hat <- Z%*%B
#         res <- apply(Y.train.hat, 1, which.max)
#         Matrix.C.train <- caret::confusionMatrix( factor(nombres[res]), y_train)
#         Y.test.hat <- (as.matrix(data[-indices, -10]))%*%as.matrix(z)%*%as.matrix(B)
#         res2 <- apply(Y.test.hat, 1, which.max)
#         Matrix.C.test <- caret::confusionMatrix( factor(nombres[res2]), data[-indices,10])
#         acc.train <- Matrix.C.train$overall['Accuracy']
#         acc.test <-  Matrix.C.test$overall['Accuracy']
#         return( c(acc.train,acc.test,p) )
#     }
# }
# Constructor.evaluar <- Constructor.evaluar.p(data = data) #se calcula el PCA
# todos <- lapply(1:9, FUN = Constructor.evaluar )  #si usara linux esto podria correrlo en multicore
# resumen <- as.data.frame(todos)  
# resumen2 <- as.data.frame(t(resumen))
# colnames(resumen2) <- c('Accuracy.train', 'Accuracy.test', 'p')
# row.names(resumen2) <- NULL
# resumen2$erro.train <- 1 - resumen2$Accuracy.train
# resumen2$erro.test <- 1 - resumen2$Accuracy.test
# resumen2$diferencia <- resumen2$Accuracy.train -resumen2$Accuracy.test
# library(ggplot2)
# ggplot(resumen2, aes(x = p, y =Accuracy.train, color= p )) +geom_line(aes(colour=I('Purple') )) +
#     geom_line(aes(x = p, y =Accuracy.test, colour =I('green'))) +
#     theme_minimal() + ggtitle('Accuracy train (morado) y test (verde) datasets cuantiles centrales de HSV de frutas')+
#     ylab('Error') + xlab('Número de componentes principales')
# ##entonces p ? 2

################## eigen faces#################
train.lm.cv <- function(cv=10, data)
{
    #funcion para evaluar por cv lm
    set.seed(0)
    p <- 2
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    y <- data[,1]
    y <- factor(y)
    Y <- model.matrix(~y-1)
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    for (i in 1:(length(breaks)-1))
    {
        #i <- 1
        indices <- breaks[i]:breaks[i+1]
        test <- data[ indices,   ]
        train <- data[ -indices,   ]
        pca <- princomp(train[,-10]) #como los datos ya estan escalados en [-1, 1] uso la matriz de varianzas y covarianzas
        z <- pca$loadings[,1:p]
        Z <- as.matrix(train[,-10]) %*%z
        y_hat <- lm(Y[ -indices,] ~ . -1 , data = as.data.frame(Z))
        b <- y_hat$coefficients
        y_hat <- Z%*%b
        res <-  apply(y_hat, 1, which.max)
        Matrix.C.train <- as.data.frame(table( factor(nombres[res]), train[,10]))
        indices <- (as.character(Matrix.C.train$Var1) == as.character(Matrix.C.train$Var2))
        acc.train[i] <- sum(Matrix.C.train$Freq[indices])/sum(Matrix.C.train$Freq)
        Y.test.hat <- (as.matrix(test[, -10]))%*%as.matrix(z)%*%as.matrix(b)
        res2 <- apply(Y.test.hat, 1, which.max)
        Matrix.C.test <- as.data.frame(table( factor(nombres[res2]), test[,10]))
        indices <- (as.character(Matrix.C.test$Var1) == as.character(Matrix.C.test$Var2))
        acc.test[i] <- sum(Matrix.C.train$Freq[indices])/sum(Matrix.C.train$Freq)
    }
    return( list(train=acc.train, test =acc.test) )
}
error.lm <- train.lm.cv(cv = 10, data)
error.lm  <- as.data.frame(error.lm)
error.lm$modelo <- 'lm'
##############vamos por el lda#############################################
train.LD_da.cv <- function(cv=10, data)
{
    library(MASS)
    #funcion para evaluar por cv lm
    set.seed(0)
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    for (i in 1:(length(breaks)-1))
    {
        indices <- sample(1:dim(data)[1], round(dim(data)[1]*.1))
        test <- data[ indices,   ]
        train <- data[ -indices,   ]
        y_hat <- lda( tipo2 ~ ., data = train) 
        y.ouput <-  predict(y_hat, data[-indices, ])
        y.ouput <- y.ouput$class
        Matrix.C.train <- as.data.frame(table( factor(nombres[y.ouput]), train[,10]))
        indices <- (as.character(Matrix.C.train[,1]) == as.character(Matrix.C.train[,2]))
        acc.train[i] <- sum(Matrix.C.train[indices, 3])/sum(Matrix.C.train[,3])
        Y.test.hat <- predict(y_hat, test)
        res2 <- Y.test.hat$class
        Matrix.C.train <- as.data.frame(table( factor(nombres[res2]), test[,10]))
        indices <- (as.character(Matrix.C.train[,1]) == as.character(Matrix.C.train[,2]))
        acc.test[i] <- sum(Matrix.C.train[indices, 3])/sum(Matrix.C.train[,3])
    }
    return( list(train=acc.train, test =acc.test) )
}
error.lda <- train.LD_da.cv(cv = 10, data)
error.lda <- as.data.frame(error.lda)
error.lda$modelo <- 'lda'
###############vamos por el QDA   ########################################
train.QDA.cv <- function(cv = 10, data)
{
    #funcion para evaluar por cv qda
    set.seed(0)
    #data <- data[ sample(1:dim(data)[1], dim(data)[1]),]
    p <- 2
    y <- data[,1]
    y <- factor(y)
    data$V1 <- NULL
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    for (i in 1:10)
    {
        i <- 1
        indices <- sample(1:1300, round(1300*.8))
        test <- data[ -indices,   ]
        train <- data[ indices,   ]
        pca <- princomp(train[,-10]) #como los datos ya estan escalados en [-1, 1] uso la matriz de varianzas y covarianzas
        z <- pca$loadings[,1:p]
        Z <- as.matrix(train[,-10]) %*%z
        y_hat <- qda( train$tipo2 ~ .  , data = as.data.frame(Z ), CV=TRUE)
        y.ouput <-  caret::confusionMatrix(table(y_hat$class, train$tipo2))
        acc.train[i] <- y.ouput$overall['Accuracy']
        Z.y <- as.matrix(test[,-10]) %*% z
        Y.test.hat <- qda(test$tipo2~ ., as.data.frame(Z.y), CV=TRUE)
        y.ouput <-  caret::confusionMatrix(table(Y.test.hat$class, test$tipo2))
        acc.test[i] <- y.ouput$overall['Accuracy']
    }
    gc()
    return( list(train=acc.train, test =acc.test) )
}
error.qda <- train.QDA.cv(cv = 10, data)
error.qda <- as.data.frame(error.qda)
error.qda$modelo <- 'qda'
################ vamos por la red ###############################3
train.NN <- function(cv=10, data)
{
    #funcion para evaluar por cv NN
    library(nnet)
    set.seed(0)
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    for (i in 1:(length(breaks)-1))
    {
        #i<- 1
        indices <- breaks[i]:breaks[i+1]
        test <- data[ indices,   ]
        train <- data[ -indices,   ]
        y_hat <- nnet(factor(tipo2)  ~ ., data = data[-indices,], size = 30) #siguiendo la recomendación de hestie
        y.ouput <-  predict(y_hat, data[-indices, ], type = 'class')
        Matrix.C.train <- caret::confusionMatrix( factor(y.ouput), factor(data$tipo2[-indices])) #error de train
        Y.test.hat <- predict(y_hat, data[indices,], type = 'class')
        res2 <- Y.test.hat
        Matrix.C.test <- as.data.frame(table( res2, test[,10]))
        indices <- (as.character(Matrix.C.test[,1]) == as.character(Matrix.C.test[,2]))
        acc.test[i] <- sum(Matrix.C.test[indices, 3])/sum(Matrix.C.test[,3])
        acc.train[i] <- Matrix.C.train$overall['Accuracy']
    }
    gc()
    return( list(train=acc.train, test =acc.test) )
}
error.nn <- train.NN(cv = 10, data)
error.nn <- as.data.frame(error.nn)
error.nn$modelo <- 'nn'
################ vamor por el favorito de todos SVM###########################
train.SVM.init <- function(cv = 10, data, x)
{
    library(e1071)
    set.seed(0)
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    function(x){
        for (i in 1:(length(breaks)-1))
        {
            indices <- breaks[i]:breaks[i+1]
            test <- data[ indices,   ]
            train <- data[ -indices,   ]
            y_hat <- svm(factor(tipo2)  ~ ., data = data[-indices,], kernel='linear', cost = x ) #siguiendo la recomendación de hestie
            y.ouput <-  predict(y_hat, data[-indices, ], type = 'class')
            Matrix.C.train <- caret::confusionMatrix( factor(y.ouput), factor(data$tipo2[-indices])) #error de train
            Y.test.hat <- predict(y_hat, data[indices,], type = 'class')
            res2 <- Y.test.hat
            Matrix.C.test <- as.data.frame(table( res2, test[,10]))
            indices <- (as.character(Matrix.C.test[,1]) == as.character(Matrix.C.test[,2]))
            acc.test[i] <- sum(Matrix.C.test[indices, 3])/sum(Matrix.C.test[,3])
            acc.train[i] <- Matrix.C.train$overall['Accuracy']
        }
        gc()
        return( list(train=acc.train, test =acc.test) )
    }
}
train.SVM <- train.SVM.init(cv = 10, data = data, x)
error.SVM <- train.SVM(190.1)#determinado por busqueda exaustiva en [.1, 20]
error.SVM <- as.data.frame(error.SVM)
error.SVM$modelo <- 'SVM'
############################################  busqueda en grid del parametro C de SVM el mejor es .1
# train.SVM <- train.SVM.init(cv = 10, data = data, x)
# c.tuning <- seq(.1, 200, by = 10)
# searh.grid.SVM <- mclapply(FUN = train.SVM,  X= c.tuning, mc.cores = (detectCores()-1))
# # searh.grid.SVM
# z <- as.data.frame(searh.grid.SVM)
# z2 <- as.data.frame(apply(z, 2, mean))
# z.vis <- matrix(0, ncol = 2, nrow = 20)
# impares <-  seq(1,dim(z2)[1], by = 2)
# z.vis[,1 ] <- z2$`apply(z, 2, mean)`[impares]
# z.vis[,2 ] <- z2$`apply(z, 2, mean)`[impares+1]
# library(ggplot2)
# z.vis <- as.data.frame(z.vis)
# colnames(z.vis) <- c('Acc.Train', 'Acc.Test')
# z.vis$Indice.Grid <- 1:length(c.tuning)
# #saveRDS(z.vis, file ='tuning_SVM.rds')
# #z.vis <-readRDS(file='tuning_SVM.rds')
# p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
#     geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
#     ggtitle('Precisión promedio por valor del grid (10-fold): SVM')
# p2 <- ggplotly(p2) #distro en bayes
# p2
############# vamos por el arbol################################
train.arbol.init <- function(cv = 10, data, grid)
{
    library(rpart)
    set.seed(0)
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    grid <- grid
    function(x){
        for (i in 1:(length(breaks)-1))
        {
            indices <- breaks[i]:breaks[i+1]
            test <- data[ indices,   ]
            train <- data[ -indices,   ]
            y_hat <- rpart(factor(tipo2)  ~ ., data = data[-indices,])
            y.ouput <-  predict(y_hat, data[-indices, ], type = 'class')
            Matrix.C.train <- caret::confusionMatrix( factor(y.ouput), factor(data$tipo2[-indices])) #error de train
            Y.test.hat <- predict(y_hat, data[indices,], type = 'class')
            res2 <- Y.test.hat
            Matrix.C.test <- as.data.frame(table( as.character(res2), as.character(test[,10])))
            indices <- (as.character(Matrix.C.test[,1]) == as.character(Matrix.C.test[,2]))
            acc.test[i] <- sum(Matrix.C.test[indices, 3])/sum(Matrix.C.test[,3])
            acc.train[i] <-  ifelse(is.null(Matrix.C.test$overall['Accuracy']),0,1) 
        }
        return( list(train=acc.train, test =acc.test) )
    }
}
#tuning el arbol 
grid <- data.frame(maxdepth = rep(1:30, each = 10), minsplit = rep((1:10),30 ))
grid <- unique(grid)
train.arbol <- train.arbol.init(cv = 10, data = data, grid = grid)
error.arbol <- train.arbol(5) #el que sea
error.arbol <- as.data.frame(error.arbol)
error.arbol$modelo <- 'arbol'
#tuning el arbol 
# train.arbol <- train.arbol.init(cv = 10, data = data, grid = grid)
# searh.grid.arbol <- mclapply(FUN = train.arbol,  X= 1:dim(grid)[1], mc.cores = (detectCores()-1))
# z <- as.data.frame(searh.grid.arbol)
# z2 <- as.data.frame(apply(z, 2, mean))
# z.vis <- matrix(0, ncol = 2, nrow = dim(grid)[1])
# impares <-  seq(1,dim(z2)[1], by = 2)
# z.vis[,1 ] <- z2$`apply(z, 2, mean)`[impares]
# z.vis[,2 ] <- z2$`apply(z, 2, mean)`[impares+1]
# library(ggplot2)
# z.vis <- as.data.frame(z.vis)
# colnames(z.vis) <- c('Acc.Train', 'Acc.Test')
# z.vis$Indice.Grid <- 1:dim(grid)[1]
# #saveRDS(z.vis, file ='tuning_arbol.rds')
# z.vis <- readRDS(file='tuning_arbol.rds')
# p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
#     geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
#     ggtitle('Precisión promedio por valor del grid (10-fold): Arboles ')
# p2 <- ggplotly(p2) #distro en bayes
# p2


###################### NO  reutilizamos nuestra implementación de adaboost#################
set.seed(0)
train.ada.init <- function(cv = 10, data, grid)
{
    set.seed(0)
    library(adabag)
    bloque <- round(dim(data)[1]/cv)
    breaks <- c(seq(1, dim(data)[1], by = bloque  ), dim(data)[1])
    acc.train <- rep(0, cv)
    acc.test <- rep(0, cv)
    grid <- grid
    function(x){
        indices <- sample(1:dim(data)[1], round(dim(data)[1]*.9))
        y_hat <- boosting( tipo2~ ., data= data[-indices,], boos=FALSE, 
                           coeflearn = 'Zhu', mfinal = grid[x, 'mfinal'], 
                           control=rpart.control(
                                 maxdepth= grid[x, 'maxdepth'] , 
                                 minsplit = grid[x, 'minsplit' ], cp =0.01 ) ) 
                           
        y.ouput <-  predict(y_hat, data[-indices, ], type = 'class')
        Matrix.C.train <- caret::confusionMatrix( factor(y.ouput$class), factor(data$tipo2[-indices])) #error de train
        Y.test.hat <- predict(y_hat, data[indices,], type = 'class')
        res2 <- Y.test.hat
        Matrix.C.test <- caret::confusionMatrix( factor(res2$class), factor(data$tipo2[indices]))
        acc.train[x] <- Matrix.C.train$overall['Accuracy']
        acc.test[x] <-  Matrix.C.test$overall['Accuracy']
        gc()
        return( list(train=acc.train, test =acc.test) )
    }
}
grid.ada <- data.frame(minsplit = rep(seq(5, 20, by=2),  each = 9 ),
                       maxdepth = rep(seq(5,  15, by =5 ), each =  3), 
                       mfinal = rep(c(50, 100, 500), 4) )
grid.ada <- unique(grid.ada)
train.ada <- train.ada.init(cv = 10, data = data, grid = grid.ada)
error.ada <- train.ada(3) #determinado con busqueda en grid
error.ada <- as.data.frame(error.ada)
error.ada$modelo <- 'ada'
##################tuning de ada boost ######################################
# searh.grid.ada <- mclapply(FUN = train.ada,  X= 1:dim(grid.ada)[1], mc.cores = (detectCores()-1))
# o.2 <- searh.grid.ada
# o.3 <-o.2
# error.ada <- unlist(searh.grid.ada)
# #error.ada <- as.data.frame(error.ada)
# z <- matrix(-1, ncol = 2, nrow = 72)
# for(i in 1:length(o.2))
# {
#     foo1 <- o.2[[i]]$train
#     foo1[foo1==0] <- NA 
#     z[i, 1] <- mean(foo1, na.rm = TRUE)
#     foo1 <- o.2[[i]]$test
#     foo1[foo1==0] <- NA 
#     z[i, 2] <- mean(foo1, na.rm = TRUE)
# }
# z <- as.data.frame(z)
# names(z) <- c('Acc.Train', 'Acc.Test')
# z$Indice.Grid <- 1:72
# library(ggplot2)
# z.vis <- z
# #saveRDS(z.vis, file ='tuning_ada.rds')
# readRDS(file='tuning_ada.rds')
# p2 <- ggplot(z.vis, aes(x=Acc.Train, y=Acc.Test , color = factor(Indice.Grid)))+
#     geom_point() +  theme(legend.title = element_blank()) +theme_minimal() +
#     ggtitle('Precisión promedio por valor del grid (10-fold): Arboles ')
# p2 <- ggplotly(p2) #distro en bayes
# p2
###########3grafico para comparar los desempellos en el dataset de numeros ##########
gc()
library(ggpubr)
errores <- rbind(error.lm, error.lda, error.qda, error.nn, error.SVM, error.arbol, error.ada)
p1 <-ggplot(errores, aes(x = modelo, y = train, color = modelo)) + geom_boxplot() +geom_jitter(width = 0.2, alpha = 0.4, color ='navy')+
    theme_minimal() +xlab('') + ylab('Presición en conjunto de entrenamiento')+
    ggtitle('Desempeño entre modelos en 10-Folds (conjunto de imagenes)')
p2 <- ggplot(errores, aes(x = modelo, y = test, color = modelo)) + geom_boxplot() +geom_jitter(width = 0.2, alpha = 0.5, color = 'navy')+
    theme_minimal() +xlab('') + ylab('Presición en conjunto de prueba')+
    ggtitle('Desempeño entre modelos en 10-Folds (conjunto de imagenes)')
ggarrange(p1,p2)
################################analizis de fotos propias
setwd(path.escritura <- '/home/fou/Desktop/MCE_CIMAT/Second/CienciaDeDatos/Tarea4/Ejercicio3/frutas_propias/imagenes_de_foo/')
imagenes <-dir()
test <- mapply(1:length(imagenes), FUN = reduce.a.medianas.HSV) 
test <- as.data.frame(t(test))
colnames(test) <- c('H.25','H.5', 'H.75',
                        'S.25','S.5', 'S.75',
                        'V.25','V.5', 'V.75')
modelo.svm  <-  svm(factor(tipo2)  ~ ., data = data, kernel='linear', cost = 190.1 ) #siguiendo la recomendación de hestie
y_hat <-  predict(modelo.svm, test , type = 'class')
comparacion <- data.frame(y = imagenes, y_hat = y_hat)
